#!/bin/sh
# Create: 2022-08-17

ab -n 800000 http://localhost:8080/
