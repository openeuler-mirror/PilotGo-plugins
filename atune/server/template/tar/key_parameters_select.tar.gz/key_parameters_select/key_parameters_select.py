#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Copyright (c) 2020 Huawei Technologies Co., Ltd.
# A-Tune is licensed under the Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#     http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
# PURPOSE.
# See the Mulan PSL v2 for more details.
# Create: 2020-09-04
"""
This program is used as key parameters select
"""

X1 = 1
X2 = 1
X3 = 1
X4 = 1
X5 = 1
X6 = 1
X7 = 1
X8 = 1
X9 = 1
X10 = 1
X11 = 1
X12 = 1
X13 = 1
X14 = 1
X15 = 1
X16 = 1
X17 = 1
X18 = 1
X19 = 1
X20 = 1
Y = X1 ** 1 + X2 ** 2 + X3 ** 3 + X4 ** 4 + X5 ** 5 + X6 ** 6 + X7 ** 7 + X8 ** 8 + X9 ** 9 \
    + X10 ** 10 + X11 ** 11 + X12 ** 12 + X13 ** 13 + X14 ** 14 + X15 ** 15 + X16 ** 16 \
    + X17 ** 17 + X18 ** 18 + X19 ** 19 + X20 ** 20
print("Y = %s" % Y)
