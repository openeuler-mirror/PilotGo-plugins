1. Prepare the environment  
sh prepare.sh
2. Start to tuning  
atune-adm tuning --project key_parameters_select --detail key_parameters_select_client.yaml
3. Restore the environment  
atune-adm tuning --restore --project key_parameters_select
